Gallery
========

The Starry Night Over the Rhone (1888), Vincent van Gogh.
Public domain (the artist died in 1890).

Scanned via Wikimedia Commons. PutPlay opens the archive with
range reads only - the file itself stays on put.io.
